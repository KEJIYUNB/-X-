#!/system/bin/sh
# KEJIYU - 微信模块替换工具 v8.8.8

# 当前脚本所在目录
current_dir="$(cd "$(dirname "$0")" && pwd)"

# 打印函数
print_separator() { echo "------------------------------------------------------------"; }
print_success() { echo "[✓] $1"; }
print_warning() { echo "[⚠] $1"; }
print_error() { echo "[✗] $1"; }
print_info() { echo "[•] $1"; }
print_question() { echo -n "[?] $1: "; }

# 格式化文件大小（KB/MB）
format_size() {
    local size=$(du -sh "$1" | cut -f1)
    if [ "${size: -1}" = "M" ]; then
        echo "$size"
    elif [ "${size: -1}" = "K" ]; then
        echo "$size"
    else
        local kb=$(echo "scale=1; $size/1024" | bc -l)
        echo "$kb KB"
    fi
}

# 修复权限和所有者
fix_permissions() {
    target_path="$1"
    folder_name="$2"
    
    mm_user=$(stat -c "%U" "/data/data/com.tencent.mm" 2>/dev/null)
    mm_group=$(stat -c "%G" "/data/data/com.tencent.mm" 2>/dev/null)
    [ -z "$mm_user" ] && mm_user="u0_a999"
    [ -z "$mm_group" ] && mm_group="u0_a999"
    
    print_info "修复 $folder_name 权限 (所有者: $mm_user:$mm_group)"
    chown -R $mm_user:$mm_group "${target_path}${folder_name}" 2>/dev/null
    find "${target_path}${folder_name}" -type d -exec chmod 755 {} + 2>/dev/null
    find "${target_path}${folder_name}" -type f -exec chmod 644 {} + 2>/dev/null
    find "${target_path}${folder_name}" -name "*.so" -exec chmod 755 {} + 2>/dev/null
    print_success "权限修复完成"
}

# 替换模式处理函数
replace_mode() {
    src="$1"
    dest="$2"
    folder_name="$3"
    mode="$4"
    
    if [ ! -d "$src" ]; then
        print_warning "$folder_name 源文件夹不存在，跳过"
        return 1
    fi

    mkdir -p "$dest" 2>/dev/null || { print_error "无法创建目标目录"; return 2; }
    full_dest="${dest}${folder_name}"
    
    if [ "$mode" -eq 1 ]; then
        if [ -e "$full_dest" ]; then
            print_info "完全删除旧文件夹 $folder_name"
            rm -rf "$full_dest" 2>/dev/null
        fi
        print_info "复制 $folder_name (完全替换模式)"
        cp -r "$src" "$dest" || { print_error "复制失败"; return 4; }
    
    elif [ "$mode" -eq 2 ]; then
        if [ -e "$full_dest" ]; then
            print_info "清空旧文件夹内容 $folder_name"
            rm -rf "$full_dest"/* "$full_dest"/.[!.]* 2>/dev/null
        else
            mkdir -p "$full_dest" 2>/dev/null
        fi
        print_info "合并复制 $folder_name (保留目录结构)"
        cp -rf "$src"/* "$src"/.[!.]* "$full_dest" || { print_error "合并复制失败"; return 4; }
    
    elif [ "$mode" -eq 3 ]; then
        if [ -e "$full_dest" ]; then
            print_info "$folder_name 已存在，跳过安装"
            return 5
        fi
        print_info "全新安装 $folder_name (不存在时创建)"
        cp -r "$src" "$dest" || { print_error "全新安装失败"; return 4; }
    fi
    
    print_success "$folder_name 操作完成"
    if [ "${dest#/data}" != "$dest" ]; then
        fix_permissions "$dest" "$folder_name"
    fi
    return 0
}

# 处理四个文件夹（根据版本选择路径）
handle_folders_with_version() {
    local mode="$1"
    local is_clone="$2"  # true为分身版，false为主版
    
    # 主版目标路径（用空格分隔的字符串代替数组）
    local main_dests="/storage/emulated/0/Android/data/com.tencent.mm/files/ /storage/emulated/0/Android/data/com.tencent.mm/files/ /data/data/com.tencent.mm/files/ /data/data/com.tencent.mm/"
    
    # 分身版目标路径
    local clone_dests="/storage/emulated/999/Android/data/com.tencent.mm/files/ /storage/emulated/999/Android/data/com.tencent.mm/files/ /data/data/com.tencent.mm/files/ /data/data/com.tencent.mm/"
    
    # 选择目标路径
    local dests=$main_dests
    if [ "$is_clone" = "true" ]; then
        dests=$clone_dests
    fi
    
    # 文件夹列表（用空格分隔的字符串代替数组）
    local folders="X WechatXposed x7_3.0 databases"
    local i=0
    for folder in $folders; do
        # 提取对应位置的目标路径
        set -- $dests
        shift $i
        local dest=$1
        
        print_separator
        print_info "处理 $folder"
        
        if [ "${dest#/data}" != "$dest" ] && [ "$(id -u)" -ne 0 ]; then
            print_warning "非root权限，跳过/data路径"
            i=$(($i + 1))
            continue
        fi
        
        replace_mode "$current_dir/$folder" "$dest" "$folder" "$mode"
        i=$(($i + 1))
    done
}

# 处理备用模块
handle_backup_module() {
    local mode="$1"
    local is_clone="$2"  # true为分身版，false为主版
    
    # 确定目标路径
    local dest_base=""
    if [ "$is_clone" = "true" ]; then
        dest_base="/data/user/999/com.tencent.mm/"
    else
        dest_base="/data/user/0/com.tencent.mm/"
    fi
    
    local folder="BEIYONG"
    local src="$current_dir/$folder"
    
    print_separator
    print_info "处理备用模块 $folder"
    
    if [ ! -d "$src" ]; then
        print_warning "$folder 源文件夹不存在，跳过"
        return 1
    fi
    
    if [ "$(id -u)" -ne 0 ]; then
        print_warning "非root权限，无法访问/data路径"
        return 2
    fi
    
    replace_mode "$src" "$dest_base" "$folder" "$mode"
}

# 主菜单函数
main_menu() {
    while true; do
        clear
        echo
        echo "微信模块替换工具 v8.8.8"
        print_separator
        
        # 显示可用模块及大小
        print_info "当前可用模块:"
        local folders="X WechatXposed x7_3.0 databases BEIYONG"
        for folder in $folders; do
            if [ -d "$current_dir/$folder" ]; then
                local size=$(format_size "$current_dir/$folder")
                print_info "  - $folder ($size)"
            else
                print_warning "  - [缺失] $folder"
            fi
        done
        print_separator
        
        # 选择版本（主版/分身版）
        print_info "请选择目标微信版本："
        print_info "1) 主应用版（默认安装路径）"
        print_info "2) 分身版（如双开微信）"
        print_info "0) 退出程序"
        print_info "按回车键退出程序"
        print_separator
        
        # 无回车输入
        print_question "请选择 (0-2)"
        read -n 1 -s choice
        echo
        
        # 检测回车键（空输入）
        if [ -z "$choice" ]; then
            echo
            print_info "程序已退出"
            exit 0
        fi
        
        case "$choice" in
            1) 
                print_info "已选择: 主应用版"
                is_clone="false"
                module_menu
                ;;
            2) 
                print_info "已选择: 分身版"
                is_clone="true"
                module_menu
                ;;
            0)
                echo
                print_info "程序已退出"
                exit 0
                ;;
            *)
                print_warning "无效选择，请重新输入"
                sleep 1
                ;;
        esac
    done
}

# 模块选择菜单
module_menu() {
    while true; do
        clear
        echo
        echo "微信模块替换工具 v8.8.8"
        print_separator
        print_info "当前目标: $([ "$is_clone" = "true" ] && echo "分身版" || echo "主应用版")"
        print_separator
        
        # 选择模块类型
        print_info "请选择要使用的模块类型："
        print_info "1) 主模块（标准功能）"
        print_info "2) 备用模块（特殊功能）"
        print_info "0) 返回上一级"
        print_info "按回车键退出程序"
        print_separator
        
        # 无回车输入
        print_question "请选择 (0-2)"
        read -n 1 -s module_choice
        echo
        
        # 检测回车键（空输入）
        if [ -z "$module_choice" ]; then
            echo
            print_info "程序已退出"
            exit 0
        fi
        
        case "$module_choice" in
            1) 
                print_info "已选择: 主模块"
                mode_menu
                ;;
            2) 
                print_info "已选择: 备用模块"
                mode_menu
                ;;
            0)
                return  # 返回主菜单
                ;;
            *)
                print_warning "无效选择，请重新输入"
                sleep 1
                ;;
        esac
    done
}

# 模式选择菜单
mode_menu() {
    while true; do
        clear
        echo
        echo "微信模块替换工具 v8.8.8"
        print_separator
        print_info "当前目标: $([ "$is_clone" = "true" ] && echo "分身版" || echo "主应用版")"
        print_info "当前模块: $([ "$module_choice" = "1" ] && echo "主模块" || echo "备用模块")"
        print_separator
        
        # 选择替换模式
        print_info "请选择替换模式："
        print_info "1) 完全替换（删除旧文件夹后新建 - 最干净）"
        print_info "2) 合并替换（清除内容后覆盖 - 保留位置）"
        print_info "3) 全新安装（不存在时创建）"
        print_info "0) 返回上一级"
        print_info "按回车键退出程序"
        print_separator
        
        # 无回车输入
        print_question "请选择 (0-3)"
        read -n 1 -s mode_choice
        echo
        
        # 检测回车键（空输入）
        if [ -z "$mode_choice" ]; then
            echo
            print_info "程序已退出"
            exit 0
        fi
        
        case "$mode_choice" in
            [1-3]) 
                # 显示选择的模式
                case "$mode_choice" in
                    1) print_info "已选择: 完全替换模式" ;;
                    2) print_info "已选择: 合并替换模式" ;;
                    3) print_info "已选择: 全新安装模式" ;;
                esac
                print_separator
                
                # 执行操作
                if [ "$module_choice" = "1" ]; then
                    handle_folders_with_version "$mode_choice" "$is_clone"
                else
                    handle_backup_module "$mode_choice" "$is_clone"
                fi
                
                # 操作完成提示
                echo
                print_info "操作已完成，建议重启微信使模块生效"
                print_separator
                
                # 询问是否继续
                print_question "按任意键返回主菜单，或按 0 退出"
                read -n 1 -s continue_choice
                echo
                if [ -z "$continue_choice" ]; then
                    # 按回车返回主菜单
                    print_info "返回主菜单"
                elif [ "$continue_choice" = "0" ]; then
                    print_info "程序已退出"
                    exit 0
                else
                    print_info "返回主菜单"
                fi
                return  # 返回主菜单
                ;;
            0)
                return  # 返回模块选择菜单
                ;;
            *)
                print_warning "无效选择，请重新输入"
                sleep 1
                ;;
        esac
    done
}

# 主程序入口
main_menu